========================================================================
   LIBRARY BOOK ISSUE MANAGEMENT SYSTEM - COMPLETE SUBMISSION PACKAGE
========================================================================

This single archive contains all codes, frontend assets, database scripts,
documentation, and presentation slides for the Library Management System:

FOLDER STRUCTURE:
-----------------
1_Frontend_Code/
    - index.html   (Semantic HTML5 dashboard & modal layouts)
    - css/style.css (Modern responsive stylesheet with glassmorphism)
    - js/app.js    (Vanilla JavaScript controller using Fetch API)

2_Full_Source_Code/
    - src/main/java/com/library/
        * LibraryApplication.java (Spring Boot main class + DB initializer)
        * controller/ (BookController, MemberController, IssueController, StatsController)
        * dao/        (BookDao, MemberDao, IssueDao using JDBC)
        * model/      (Book, Member, BookIssue POJOs)
    - src/main/resources/
        * application.properties (MySQL connection settings)
        * db/schema.sql (Database schema & sample seed data)
        * static/ (Frontend web UI)
    - pom.xml (Maven build configuration for Java 21 & Spring Boot 3)
    - run.bat (1-click starter script for Windows)
    - Dockerfile (Container configuration for cloud deployment)

3_Documentation_and_Presentation/
    - Library_Management_System_Complete_Code_Documentation.pdf
      (Comprehensive printable PDF with all source code and architecture)
    - Library_Book_Issue_Management_System.pptx
      (Complete 8-slide PowerPoint presentation with Problem Statement & Objectives)
========================================================================
